import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetByMerchantComponent } from './get-by-merchant.component';

describe('GetByMerchantComponent', () => {
  let component: GetByMerchantComponent;
  let fixture: ComponentFixture<GetByMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetByMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetByMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
