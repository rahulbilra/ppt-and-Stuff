import { Component, OnInit } from '@angular/core';
import { Purchase } from '../Purchase';
import { PurchaseService } from '../purchase.service';

@Component({
  selector: 'app-get-by-merchant',
  templateUrl: './get-by-merchant.component.html',
  styleUrls: ['./get-by-merchant.component.css']
})
export class GetByMerchantComponent implements OnInit {

  listProduct:Purchase;

  constructor(private service :PurchaseService) { }

  ngOnInit() {
  }

  merchant(data)
  {
  this.service.getmerchant(data.merchantID).subscribe(data =>this.listProduct=data);
  }

}
