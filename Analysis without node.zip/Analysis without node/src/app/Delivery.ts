export class Delivery
{
    product_Id:number;
    dateOfOrd:Date;
    noOfDaysForDelivery:number;
    status:String
}