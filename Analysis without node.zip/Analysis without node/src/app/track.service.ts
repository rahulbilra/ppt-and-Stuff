import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Delivery } from './Delivery';

@Injectable({
  providedIn: 'root'
})
export class TrackService {

  constructor(private http:HttpClient) {
   
   
  }
  getAll() :Observable<any>
  {
    return this.http.get<Delivery>('http://localhost:9090/getAllTrack');
  }
  getProduct(product_Id): Observable<any>
  {
    //console.log(merchantID);
    return this.http.get<number>("http://localhost:9090/track/" + product_Id);
  }
}


