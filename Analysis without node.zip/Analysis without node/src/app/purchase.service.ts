import { Injectable } from '@angular/core';


import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Purchase } from './Purchase';

@Injectable({
  providedIn: 'root'
})
export class PurchaseService {

  constructor(private http:HttpClient) {
   
   
   }
   getAll() :Observable<any>
   {
     return this.http.get<Purchase>('http://localhost:9090/getAll');
   }
   getmerchant(merchantID): Observable<any>
  {
    console.log(merchantID);
    return this.http.get<number>("http://localhost:9090/merchant/" + merchantID);
  }
  getProduct(productID): Observable<any>
  {
    //console.log(merchantID);
    return this.http.get<number>("http://localhost:9090/product/" + productID);
  }
}
