export class Purchase{
    productID: number;
        productName: String;
        quantity: number;
        customerID: number;
        merchantID: number;
        productPrice: number;
}