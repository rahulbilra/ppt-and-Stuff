import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetByProductIDComponent } from './get-by-product-id.component';

describe('GetByProductIDComponent', () => {
  let component: GetByProductIDComponent;
  let fixture: ComponentFixture<GetByProductIDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetByProductIDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetByProductIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
