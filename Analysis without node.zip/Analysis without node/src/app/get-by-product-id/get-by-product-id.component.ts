import { Component, OnInit } from '@angular/core';
import { PurchaseService } from '../purchase.service';
import { Purchase } from '../Purchase';

@Component({
  selector: 'app-get-by-product-id',
  templateUrl: './get-by-product-id.component.html',
  styleUrls: ['./get-by-product-id.component.css']
})
export class GetByProductIDComponent implements OnInit {
  listId:Purchase[];

  constructor(private service:PurchaseService) { }

  ngOnInit() {
  }
  getProduct(data)
  {
    this.service.getProduct(data.productID).subscribe(data =>this.listId=data)
  }

}
