import { Component } from '@angular/core';
import { Purchase } from './Purchase';
import { PurchaseService } from './purchase.service';
import { GetByMerchantComponent } from './get-by-merchant/get-by-merchant.component';
import { Routes, RouterModule } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  
  
}
