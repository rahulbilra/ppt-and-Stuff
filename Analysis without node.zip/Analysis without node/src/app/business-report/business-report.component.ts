import { Component, OnInit } from '@angular/core';
import { Purchase } from '../Purchase';
import { PurchaseService } from '../purchase.service';
import { TrackService } from '../track.service';
import { Delivery } from '../Delivery';

@Component({
  selector: 'app-business-report',
  templateUrl: './business-report.component.html',
  styleUrls: ['./business-report.component.css']
})
export class BusinessReportComponent implements OnInit {

  details: Delivery[];

  constructor(private service: TrackService) { }

  ngOnInit() {
    this.getAll();
  }

  getAll() {
    
    return this.service.getAll().subscribe(data=>this.details=data);
    
  }

}
