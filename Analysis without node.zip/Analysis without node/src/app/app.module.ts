import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GetByMerchantComponent } from './get-by-merchant/get-by-merchant.component';
import { Routes, RouterModule } from '@angular/router';
import { BusinessReportComponent } from './business-report/business-report.component';
import { GetByProductIDComponent } from './get-by-product-id/get-by-product-id.component';
import { SearchbyidComponent } from './searchbyid/searchbyid.component';


const routes: Routes = [
  { path: 'report', component: BusinessReportComponent },
  { path: 'status', component: SearchbyidComponent },
  { path: 'product', component: GetByProductIDComponent },
  { path: 'merchant',      component: GetByMerchantComponent }];
 @NgModule({
  declarations: [
    AppComponent,BusinessReportComponent,
    GetByMerchantComponent,GetByProductIDComponent, SearchbyidComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(routes)
   
  ],
  providers: [HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
