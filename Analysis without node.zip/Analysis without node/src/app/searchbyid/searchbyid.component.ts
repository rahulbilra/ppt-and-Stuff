import { Component, OnInit } from '@angular/core';
import { Delivery } from '../delivery';
import { TrackService } from '../track.service';

@Component({
  selector: 'app-searchbyid',
  templateUrl: './searchbyid.component.html',
  styleUrls: ['./searchbyid.component.css']
})
export class SearchbyidComponent implements OnInit {

  listId:Delivery[];

  constructor(private service:TrackService) { }

  ngOnInit() {
  }
  getProduct(data)
  {
    this.service.getProduct(data.product_Id).subscribe(data =>this.listId=data)
  }

}
