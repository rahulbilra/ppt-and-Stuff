package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cap;
import com.capgemini.capstore.dao.TrackDaoInterface;
@Service
public class TrackServiceImpl implements TrackService{

	@Autowired
	TrackDaoInterface dao;
	@Override
	public List<Cap> getAllTrack() {
		// TODO Auto-generated method stub
		return dao.getAllTrack();
	}
	@Override
	public List<Cap> getbyTrackId(int product_Id) {
		// TODO Auto-generated method stub
		return dao.getByTrackId(product_Id);
	}

}
