package com.capgemini.capstore.dao;

import java.util.List;



import com.capgemini.capstore.beans.Purchase;

public interface PurchaseDaoInterface  {
	List<Purchase> getAllPurchase();
	List<Purchase> getbyMerchantId(int merchantID);
	List<Purchase> getbyProductId(int productID);

}
