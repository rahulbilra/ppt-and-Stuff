package com.capgemini.capstore.beans;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "capgTracking")
public class Cap {
	@Id
	private int product_Id;
	private Date dateOfOrd;
	private long noOfDaysForDelivery;
	private String status;

	public int getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfOrd() {
		return dateOfOrd;
	}

	public void setDateOfOrd(Date dateOfOrd) {
		this.dateOfOrd = dateOfOrd;
	}

	public long getNoOfDaysForDelivery() {
		return noOfDaysForDelivery;
	}

	public void setNoOfDaysForDelivery(long noOfDaysForDelivery) {
		this.noOfDaysForDelivery = noOfDaysForDelivery;
	}

}
