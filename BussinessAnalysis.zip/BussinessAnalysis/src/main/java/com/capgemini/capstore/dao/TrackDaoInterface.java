package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.Cap;

public interface TrackDaoInterface {
	public List<Cap> getAllTrack();

	public List<Cap> getByTrackId(int product_Id);

}
