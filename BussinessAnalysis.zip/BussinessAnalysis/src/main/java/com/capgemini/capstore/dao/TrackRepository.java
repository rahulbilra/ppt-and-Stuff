package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Cap;

@Repository
public interface TrackRepository extends JpaRepository<Cap,Integer>{
	@Query("from Cap where product_Id=:product_Id")
	List<Cap> getTrackByProductid(@Param("product_Id")int product_Id);

}
