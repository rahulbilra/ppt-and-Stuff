package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Cap;
@Repository
public class TrackDaoImpl implements TrackDaoInterface{
	@Autowired
	TrackRepository repository;

	@Override
	public List<Cap> getAllTrack() {
		// TODO Auto-generated method stub
		return repository.findAll(); 
	}

	@Override
	public List<Cap> getByTrackId(int product_Id) {
		// TODO Auto-generated method stub
		return repository.getTrackByProductid(product_Id);
	}

}
