package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.dao.PurchaseDaoInterface;
@Service
public class PurchaseServiceImpl implements PurchaseService {
	@Autowired
	PurchaseDaoInterface dao;

	@Override
	public List<Purchase> getAllPurchase() {
		// TODO Auto-generated method stub
		return dao.getAllPurchase();
	}

	@Override
	public List<Purchase> getbyMerchantId(int merchantID) {
		// TODO Auto-generated method stub
		return dao.getbyMerchantId(merchantID);
	}

	@Override
	public List<Purchase> getbyProductId(int productID) {
		// TODO Auto-generated method stub
		return dao.getbyProductId(productID);
	}

	

}
