package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Purchase;
@Repository
public class PurchaseDaoImpl implements PurchaseDaoInterface {
	@Autowired
	PurchaseRepository repository;

	@Override
	public List<Purchase> getAllPurchase() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public List<Purchase> getbyMerchantId(int merchantID) {
		// TODO Auto-generated method stub
		return repository.getProductByMerchid(merchantID);
	}

	@Override
	public List<Purchase> getbyProductId(int productID) {
		// TODO Auto-generated method stub
		return repository.getProductByProductid(productID);
	}

	

	

}
