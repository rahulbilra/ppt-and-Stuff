package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Purchase;
@Repository
public interface PurchaseRepository extends JpaRepository<Purchase,Integer>{
	

	@Query("from Purchase where merchantID=:merchantID")
	List<Purchase> getProductByMerchid(@Param("merchantID")int merchantID);
	@Query("from Purchase where productID=:productID")
	List<Purchase> getProductByProductid(@Param("productID")int productID);
	

}
