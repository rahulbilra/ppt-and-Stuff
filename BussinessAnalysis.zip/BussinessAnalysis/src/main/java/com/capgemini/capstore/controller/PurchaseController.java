package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.service.PurchaseService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class PurchaseController {
	@Autowired
	PurchaseService service;
	
	@GetMapping("/getAll")
    public List<Purchase> all(){
        List<Purchase> list=service.getAllPurchase();
        return list;
    }

	@GetMapping(value="/merchant/{merchantID}")
	public List<Purchase> getByMerchantId(@PathVariable int merchantID)
	{
		//System.out.println(accountNo);
		return service.getbyMerchantId(merchantID);
	}
	@GetMapping(value="/product/{productID}")
	public List<Purchase> getByProductId(@PathVariable int productID)
	{
		//System.out.println(accountNo);
		return service.getbyProductId(productID);
	}

}
