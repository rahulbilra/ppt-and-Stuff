package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Cap;

public interface TrackService {
	public List<Cap> getAllTrack();

	public List<Cap> getbyTrackId(int product_Id);

}
